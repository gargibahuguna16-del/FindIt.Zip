const API_BASE = "http://localhost:8080/api";

let currentUser = JSON.parse(sessionStorage.getItem("findit_user")) || null;
let currentTypeFilter = "ALL";
let allItemsCache = [];

window.onload = () => {
    renderAuthHeader();
    fetchItems();
    document.getElementById("report-date").value = new Date().toISOString().split("T")[0];
};

function renderAuthHeader() {
    const container = document.getElementById("auth-buttons-container");
    const adminNav = document.getElementById("nav-admin");

    if (currentUser) {
        if (currentUser.role === "ROLE_ADMIN") {
            adminNav.classList.remove("hidden");
        } else {
            adminNav.classList.add("hidden");
        }
        container.innerHTML = `
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-xs font-bold text-white uppercase">
                    ${currentUser.name.charAt(0)}
                </div>
                <span class="hidden sm:inline-block text-xs font-medium text-slate-300">${currentUser.name}</span>
                <button onclick="handleLogout()" title="Logout" class="text-xs text-slate-400 hover:text-rose-400 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800">
                    <i class="fa-solid fa-right-from-bracket"></i>
                </button>
            </div>
        `;
    } else {
        adminNav.classList.add("hidden");
        container.innerHTML = `
            <button onclick="openAuthModal()" class="px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition">
                Sign In / Register
            </button>
        `;
    }
}

async function handleLoginSubmit(e) {
    e.preventDefault();
    const email = document.getElementById("login-email").value.trim();
    const password = document.getElementById("login-password").value;

    try {
        const res = await fetch(`${API_BASE}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Login failed");

        currentUser = data;
        sessionStorage.setItem("findit_user", JSON.stringify(currentUser));
        renderAuthHeader();
        closeAuthModal();
        showToast(`Welcome back, ${currentUser.name}!`, "success");
    } catch (err) {
        showToast(err.message, "error");
    }
}

async function handleRegisterSubmit(e) {
    e.preventDefault();
    const name = document.getElementById("reg-name").value.trim();
    const email = document.getElementById("reg-email").value.trim();
    const password = document.getElementById("reg-password").value;

    try {
        const res = await fetch(`${API_BASE}/auth/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Registration failed");

        currentUser = data;
        sessionStorage.setItem("findit_user", JSON.stringify(currentUser));
        renderAuthHeader();
        closeAuthModal();
        showToast("Account created & signed in!", "success");
    } catch (err) {
        showToast(err.message, "error");
    }
}

function handleLogout() {
    currentUser = null;
    sessionStorage.removeItem("findit_user");
    renderAuthHeader();
    switchTab("browse");
    showToast("Signed out successfully", "info");
}

function setTypeFilter(type) {
    currentTypeFilter = type;
    document.querySelectorAll(".filter-type-btn").forEach(btn => {
        btn.classList.remove("bg-indigo-600", "text-white", "shadow");
        btn.classList.add("text-slate-400");
    });
    const active = document.getElementById(`filter-type-${type}`);
    if (active) {
        active.classList.add("bg-indigo-600", "text-white", "shadow");
        active.classList.remove("text-slate-400");
    }
    fetchItems();
}

function resetFilters() {
    document.getElementById("search-input").value = "";
    document.getElementById("filter-category").value = "";
    document.getElementById("filter-location").value = "";
    setTypeFilter("ALL");
}

async function fetchItems() {
    const search = document.getElementById("search-input").value.trim();
    const category = document.getElementById("filter-category").value;
    const location = document.getElementById("filter-location").value;

    const params = new URLSearchParams();
    if (currentTypeFilter === "RESOLVED") {
        params.append("status", "RESOLVED");
    } else if (currentTypeFilter !== "ALL") {
        params.append("type", currentTypeFilter);
    }
    if (category) params.append("category", category);
    if (location) params.append("location", location);
    if (search) params.append("search", search);

    try {
        const res = await fetch(`${API_BASE}/items?${params.toString()}`);
        const items = await res.json();
        allItemsCache = items;
        renderGrid(items);
        updateStats();
    } catch (err) {
        document.getElementById("items-count-heading").innerText = "Backend Offline — Start Spring Boot on port 8080";
        showToast("Could not connect to Spring Boot backend at localhost:8080", "error");
    }
}

async function updateStats() {
    try {
        const res = await fetch(`${API_BASE}/items`);
        const all = await res.json();
        document.getElementById("stat-total").innerText = all.length;
        document.getElementById("stat-resolved").innerText = all.filter(i => i.status === "RESOLVED").length;
        document.getElementById("stat-lost").innerText = all.filter(i => i.type === "LOST" && i.status === "ACTIVE").length;
        document.getElementById("stat-review").innerText = all.filter(i => i.status === "CLAIM_REVIEW").length;
    } catch (e) {}
}

function renderGrid(items) {
    const grid = document.getElementById("items-grid");
    const emptyState = document.getElementById("empty-state");
    document.getElementById("items-count-heading").innerText = `Showing ${items.length} Database ${items.length === 1 ? "Report" : "Reports"}`;

    if (items.length === 0) {
        grid.innerHTML = "";
        emptyState.classList.remove("hidden");
        return;
    }
    emptyState.classList.add("hidden");

    grid.innerHTML = items.map(item => {
        const isLost = item.type === "LOST";
        const isResolved = item.status === "RESOLVED";
        const isReview = item.status === "CLAIM_REVIEW";

        const badgeBg = isResolved
            ? "bg-slate-700 text-slate-300"
            : isReview
            ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
            : isLost
            ? "bg-rose-500/20 text-rose-300 border-rose-500/30"
            : "bg-emerald-500/20 text-emerald-300 border-emerald-500/30";

        const badgeText = isResolved ? "RESOLVED" : isReview ? "UNDER CLAIM REVIEW" : isLost ? "LOST ITEM" : "FOUND ITEM";

        const imgTag = item.imageUrl
            ? `<img src="${item.imageUrl}" alt="${item.title}" class="w-full h-48 object-cover rounded-t-2xl">`
            : `<div class="w-full h-48 bg-slate-800 flex flex-col items-center justify-center text-slate-600 rounded-t-2xl"><i class="fa-solid fa-image text-3xl mb-1"></i><span class="text-xs">No image</span></div>`;

        return `
            <div class="glass-card rounded-2xl flex flex-col justify-between overflow-hidden">
                <div>
                    <div class="relative">
                        ${imgTag}
                        <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full text-xs font-bold border backdrop-blur-md ${badgeBg}">${badgeText}</span>
                        <span class="absolute top-3 right-3 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-900/80 text-slate-300 border border-slate-700">${item.category}</span>
                    </div>
                    <div class="p-5 space-y-3">
                        <h3 class="text-base font-bold text-white line-clamp-1">${item.title}</h3>
                        <p class="text-xs text-slate-400 line-clamp-2 leading-relaxed">${item.description}</p>
                        <div class="pt-2 flex flex-col gap-1.5 text-xs text-slate-400 border-t border-slate-800/80">
                            <div><i class="fa-solid fa-location-dot text-indigo-400 w-4"></i> ${item.location}</div>
                            <div><i class="fa-regular fa-calendar text-indigo-400 w-4"></i> ${item.dateReported}</div>
                        </div>
                    </div>
                </div>
                <div class="p-5 pt-0">
                    <button onclick="openDetailsModal(${item.id})" class="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-indigo-600 text-slate-200 hover:text-white text-xs font-semibold transition flex items-center justify-center gap-2">
                        <span>View Details & Verify</span>
                        <i class="fa-solid fa-arrow-right text-xs"></i>
                    </button>
                </div>
            </div>
        `;
    }).join("");
}

function openReportModal(defaultType = "LOST") {
    if (!currentUser) {
        showToast("Please sign in before reporting an item", "error");
        openAuthModal();
        return;
    }
    document.getElementById("report-id").value = "";
    document.getElementById("report-title").value = "";
    document.getElementById("report-description").value = "";
    document.getElementById("report-image").value = "";
    document.getElementById("modal-report-title").innerText = "Report an Item";
    document.getElementById(defaultType === "FOUND" ? "radio-type-found" : "radio-type-lost").checked = true;
    document.getElementById("modal-report").classList.remove("hidden");
}

function closeReportModal() {
    document.getElementById("modal-report").classList.add("hidden");
}

async function handleReportSubmit(e) {
    e.preventDefault();
    if (!currentUser) return;

    const id = document.getElementById("report-id").value;
    const payload = {
        title: document.getElementById("report-title").value.trim(),
        type: document.querySelector('input[name="reportType"]:checked').value,
        category: document.getElementById("report-category").value,
        location: document.getElementById("report-location").value,
        dateReported: document.getElementById("report-date").value,
        description: document.getElementById("report-description").value.trim(),
        imageUrl: document.getElementById("report-image").value.trim()
    };

    try {
        const url = id ? `${API_BASE}/items/${id}` : `${API_BASE}/items?userId=${currentUser.id}`;
        const method = id ? "PUT" : "POST";

        const res = await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error("Failed to save item");

        closeReportModal();
        fetchItems();
        if (!document.getElementById("page-dashboard").classList.contains("hidden")) renderDashboard();
        showToast(id ? "Report updated in MySQL!" : "New report saved to MySQL!", "success");
    } catch (err) {
        showToast(err.message, "error");
    }
}

async function openDetailsModal(id) {
    const res = await fetch(`${API_BASE}/items/${id}`);
    const item = await res.json();

    const imgMarkup = item.imageUrl ? `<img src="${item.imageUrl}" class="w-full h-64 object-cover rounded-2xl border border-slate-800">` : "";

    document.getElementById("details-modal-content").innerHTML = `
        <div class="space-y-5">
            <div class="flex items-center gap-3">
                <span class="px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300">${item.type} • ${item.status}</span>
                <span class="text-xs text-slate-400">${item.category}</span>
            </div>
            <div>
                <h2 class="text-2xl font-black text-white mb-2">${item.title}</h2>
                <div class="flex flex-wrap gap-4 text-xs text-slate-400">
                    <span><i class="fa-solid fa-location-dot text-indigo-400 mr-1"></i>${item.location}</span>
                    <span><i class="fa-regular fa-calendar text-indigo-400 mr-1"></i>${item.dateReported}</span>
                    <span><i class="fa-solid fa-user text-indigo-400 mr-1"></i>Reporter: ${item.user ? item.user.name : "Student"}</span>
                </div>
            </div>
            ${imgMarkup}
            <p class="text-sm text-slate-300 bg-slate-800/60 p-4 rounded-2xl border border-slate-800">${item.description}</p>
            
            ${item.status !== "RESOLVED" ? `
                <form onsubmit="submitClaim(event, ${item.id})" class="p-5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-3">
                    <h4 class="text-sm font-bold text-indigo-300"><i class="fa-solid fa-shield-check mr-1"></i> Submit Ownership Proof</h4>
                    <textarea id="claim-proof-input" required rows="2" placeholder="Provide serial number, lock pattern, sticker details, or contents..." class="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-slate-100"></textarea>
                    <button type="submit" class="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold">Submit Verification Claim</button>
                </form>
            ` : `<div class="text-center text-xs text-emerald-400 font-semibold py-2">This item has already been reunited.</div>`}
        </div>
    `;
    document.getElementById("modal-details").classList.remove("hidden");
}

function closeDetailsModal() {
    document.getElementById("modal-details").classList.add("hidden");
}

async function submitClaim(e, itemId) {
    e.preventDefault();
    if (!currentUser) {
        showToast("Please sign in to submit a claim", "error");
        closeDetailsModal();
        openAuthModal();
        return;
    }
    const proofDetails = document.getElementById("claim-proof-input").value.trim();
    const res = await fetch(`${API_BASE}/claims`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ itemId, userId: currentUser.id, proofDetails })
    });
    if (res.ok) {
        closeDetailsModal();
        fetchItems();
        showToast("Claim submitted to Admin & Reporter for verification!", "success");
    }
}

function switchTab(tab) {
    ["browse", "dashboard", "admin"].forEach(t => {
        document.getElementById(`page-${t}`).classList.add("hidden");
        document.getElementById(`nav-${t}`).className = "px-4 py-2 rounded-lg text-sm font-medium transition-all text-slate-400 hover:text-slate-200 hover:bg-slate-800/50";
    });
    if (tab === "admin" && currentUser?.role === "ROLE_ADMIN") {
        document.getElementById("nav-admin").classList.remove("hidden");
    }
    document.getElementById(`page-${tab}`).classList.remove("hidden");
    document.getElementById(`nav-${tab}`).className = "px-4 py-2 rounded-lg text-sm font-medium transition-all text-white bg-indigo-600 shadow";

    if (tab === "dashboard") renderDashboard();
    if (tab === "admin") renderAdmin();
}

async function renderDashboard() {
    const container = document.getElementById("user-reports-container");
    if (!currentUser) {
        container.innerHTML = `<div class="glass-panel p-8 rounded-2xl text-center"><p class="text-slate-300 mb-3">Sign in to view your reports.</p><button onclick="openAuthModal()" class="px-4 py-2 bg-indigo-600 rounded-xl text-xs font-semibold">Sign In</button></div>`;
        return;
    }
    const res = await fetch(`${API_BASE}/items/user/${currentUser.id}`);
    const myItems = await res.json();

    if (myItems.length === 0) {
        container.innerHTML = `<div class="glass-panel p-8 rounded-2xl text-center text-slate-400">You have not submitted any reports yet.</div>`;
        return;
    }

    container.innerHTML = myItems.map(item => `
        <div class="glass-panel p-5 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <span class="text-xs font-bold uppercase text-indigo-400">${item.type} • ${item.status}</span>
                <h4 class="text-base font-bold text-white">${item.title}</h4>
                <p class="text-xs text-slate-400">${item.location} — ${item.dateReported}</p>
            </div>
            <div class="flex gap-2">
                ${item.status !== "RESOLVED" ? `<button onclick="markResolved(${item.id})" class="px-3 py-1.5 bg-emerald-600/20 text-emerald-300 rounded-xl text-xs font-semibold">Mark Reunited</button>` : ""}
                <button onclick="deleteItem(${item.id})" class="px-3 py-1.5 bg-rose-500/20 text-rose-300 rounded-xl text-xs font-semibold">Delete</button>
            </div>
        </div>
    `).join("");
}

async function markResolved(id) {
    await fetch(`${API_BASE}/items/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "RESOLVED" })
    });
    fetchItems();
    renderDashboard();
    showToast("Item marked as Reunited!", "success");
}

async function deleteItem(id) {
    await fetch(`${API_BASE}/items/${id}`, { method: "DELETE" });
    fetchItems();
    if (!document.getElementById("page-dashboard").classList.contains("hidden")) renderDashboard();
    if (!document.getElementById("page-admin").classList.contains("hidden")) renderAdmin();
    showToast("Item removed from database", "info");
}

async function renderAdmin() {
    const [itemsRes, claimsRes] = await Promise.all([
        fetch(`${API_BASE}/items`),
        fetch(`${API_BASE}/claims`)
    ]);
    const items = await itemsRes.json();
    const claims = await claimsRes.json();

    document.getElementById("admin-claims-body").innerHTML = claims.map(c => `
        <tr>
            <td class="p-3 font-mono text-xs">#${c.id}</td>
            <td class="p-3 font-semibold text-white">${c.item ? c.item.title : ""}</td>
            <td class="p-3 text-slate-300">${c.user ? c.user.name : ""}</td>
            <td class="p-3 text-xs text-slate-400">${c.proofDetails}</td>
            <td class="p-3 text-xs font-bold">${c.status}</td>
            <td class="p-3 text-right space-x-1">
                <button onclick="decideClaim(${c.id}, 'APPROVED')" class="px-2.5 py-1 bg-emerald-600 text-white rounded text-xs">Approve</button>
                <button onclick="decideClaim(${c.id}, 'REJECTED')" class="px-2.5 py-1 bg-rose-600 text-white rounded text-xs">Reject</button>
            </td>
        </tr>
    `).join("");

    document.getElementById("admin-items-body").innerHTML = items.map(i => `
        <tr>
            <td class="p-3 font-mono text-xs">#${i.id}</td>
            <td class="p-3 font-semibold text-white">${i.title}</td>
            <td class="p-3 text-xs">${i.type}</td>
            <td class="p-3 text-slate-300">${i.user ? i.user.name : ""}</td>
            <td class="p-3 text-xs">${i.status}</td>
            <td class="p-3 text-right">
                <button onclick="deleteItem(${i.id})" class="px-2.5 py-1 bg-rose-500/20 text-rose-300 rounded text-xs">Delete</button>
            </td>
        </tr>
    `).join("");
}

async function decideClaim(claimId, status) {
    await fetch(`${API_BASE}/claims/${claimId}/status?status=${status}`, { method: "PUT" });
    fetchItems();
    renderAdmin();
    showToast(`Claim ${status}`, "success");
}

function openAuthModal() { document.getElementById("modal-auth").classList.remove("hidden"); }
function closeAuthModal() { document.getElementById("modal-auth").classList.add("hidden"); }

function switchAuthMode(mode) {
    document.getElementById("form-login").classList.toggle("hidden", mode !== "login");
    document.getElementById("form-register").classList.toggle("hidden", mode !== "register");
    document.getElementById("auth-tab-login").className = mode === "login" ? "text-lg font-bold text-indigo-400 border-b-2 border-indigo-500 pb-1" : "text-lg font-bold text-slate-500 pb-1";
    document.getElementById("auth-tab-register").className = mode === "register" ? "text-lg font-bold text-indigo-400 border-b-2 border-indigo-500 pb-1" : "text-lg font-bold text-slate-500 pb-1";
}

function showToast(msg, type = "info") {
    const container = document.getElementById("toast-container");
    const toast = document.createElement("div");
    const color = type === "success" ? "border-emerald-500/50 text-emerald-200" : type === "error" ? "border-rose-500/50 text-rose-200" : "border-indigo-500/50 text-slate-200";
    toast.className = `p-4 rounded-2xl border bg-slate-900/95 backdrop-blur-md shadow-2xl text-xs font-semibold pointer-events-auto ${color}`;
    toast.innerText = msg;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
}
