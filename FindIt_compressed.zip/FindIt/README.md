# FindIt — Smart Campus Lost & Found System

A complete full-stack web application built with **Java 25 LTS, Spring Boot 3, Spring Security (BCrypt), Spring Data JPA, H2/MySQL**, and a responsive **HTML5/CSS3/Vanilla JS** frontend.

## How to Open and Run in VS Code

1. **Extract** `FindIt-FullStack.zip` and open the `FindIt` folder in **VS Code**.
2. Install **JDK 25**, the **Extension Pack for Java** and **Spring Boot Extension Pack** in VS Code, plus Maven.
3. **Run the Spring Boot Backend:**
   - Open a terminal in VS Code inside the `backend` folder:
     ```bash
     cd backend
     mvn spring-boot:run
     ```
   - The default development database is an in-memory H2 database; no MySQL setup is required. Its data is reset when the backend stops.
   - To use MySQL instead, start MySQL, set `DB_USERNAME` and `DB_PASSWORD`, then run:
     ```bash
     mvn spring-boot:run -Dspring-boot.run.profiles=mysql
     ```
     You can create the database with `database/schema.sql` first, or let the configured MySQL URL create it.
   - The backend starts on `http://localhost:8080` and automatically serves the frontend!
4. **Access the App:**
   - Open `http://localhost:8080` in your browser.
   - Default accounts created automatically on startup:
     - **Admin:** `admin@univ.edu` / `admin123`
     - **Student:** `student@univ.edu` / `password123`
