package com.findit;

import com.findit.entity.Item;
import com.findit.entity.User;
import com.findit.repository.ItemRepository;
import com.findit.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class FindItApplication {
    public static void main(String[] args) {
        SpringApplication.run(FindItApplication.class, args);
    }

    @Bean
    CommandLineRunner seedDatabase(UserRepository userRepo, ItemRepository itemRepo, PasswordEncoder encoder) {
        return args -> {
            User admin = userRepo.findByEmail("admin@univ.edu").orElseGet(() -> {
                User u = new User();
                u.setName("Campus Administrator");
                u.setEmail("admin@univ.edu");
                u.setPassword(encoder.encode("admin123"));
                u.setRole("ROLE_ADMIN");
                return userRepo.save(u);
            });

            User student = userRepo.findByEmail("student@univ.edu").orElseGet(() -> {
                User u = new User();
                u.setName("Student User");
                u.setEmail("student@univ.edu");
                u.setPassword(encoder.encode("password123"));
                u.setRole("ROLE_STUDENT");
                return userRepo.save(u);
            });

            if (itemRepo.count() == 0) {
                Item i1 = new Item();
                i1.setTitle("MacBook Pro 14\" M2 (Space Gray)");
                i1.setType("LOST");
                i1.setCategory("Electronics");
                i1.setLocation("Main Library");
                i1.setDateReported("2026-11-10");
                i1.setDescription("Space gray laptop with a dark blue protective sleeve and a Python sticker on the shell.");
                i1.setImageUrl("https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=600&q=80");
                i1.setStatus("ACTIVE");
                i1.setUser(student);
                itemRepo.save(i1);

                Item i2 = new Item();
                i2.setTitle("Leather Wallet with Student ID");
                i2.setType("FOUND");
                i2.setCategory("Wallets & ID");
                i2.setLocation("Student Union");
                i2.setDateReported("2026-11-12");
                i2.setDescription("Brown genuine leather wallet found near the 2nd floor lounge.");
                i2.setImageUrl("https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=600&q=80");
                i2.setStatus("ACTIVE");
                i2.setUser(admin);
                itemRepo.save(i2);

                Item i3 = new Item();
                i3.setTitle("AirPods Pro (2nd Gen)");
                i3.setType("FOUND");
                i3.setCategory("Electronics");
                i3.setLocation("Dining Hall");
                i3.setDateReported("2026-11-13");
                i3.setDescription("White charging case inside a transparent silicone cover left on Table 12.");
                i3.setImageUrl("https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?auto=format&fit=crop&w=600&q=80");
                i3.setStatus("ACTIVE");
                i3.setUser(student);
                itemRepo.save(i3);
            }
        };
    }
}
