package com.findit.service;

import com.findit.entity.Item;
import com.findit.entity.User;
import com.findit.repository.ItemRepository;
import com.findit.repository.UserRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ItemService {
    private final ItemRepository itemRepository;
    private final UserRepository userRepository;

    public ItemService(ItemRepository itemRepository, UserRepository userRepository) {
        this.itemRepository = itemRepository;
        this.userRepository = userRepository;
    }

    public List<Item> getFilteredItems(String type, String status, String category, String location, String search) {
        if ("ALL".equalsIgnoreCase(type) || type == null || type.isBlank()) type = null;
        if ("ALL".equalsIgnoreCase(status) || status == null || status.isBlank()) status = null;
        if (category == null || category.isBlank()) category = null;
        if (location == null || location.isBlank()) location = null;
        if (search == null || search.isBlank()) search = null;
        return itemRepository.searchAndFilter(type, status, category, location, search);
    }

    public Optional<Item> getItemById(Long id) {
        return itemRepository.findById(id);
    }

    public List<Item> getItemsByUser(Long userId) {
        return itemRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public Item saveItem(Item item, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        item.setUser(user);
        if (item.getStatus() == null || item.getStatus().isBlank()) {
            item.setStatus("ACTIVE");
        }
        return itemRepository.save(item);
    }

    public Item updateItem(Long id, Item updatedItem) {
        Item item = itemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item not found"));
        if (updatedItem.getTitle() != null) item.setTitle(updatedItem.getTitle());
        if (updatedItem.getType() != null) item.setType(updatedItem.getType());
        if (updatedItem.getCategory() != null) item.setCategory(updatedItem.getCategory());
        if (updatedItem.getLocation() != null) item.setLocation(updatedItem.getLocation());
        if (updatedItem.getDateReported() != null) item.setDateReported(updatedItem.getDateReported());
        if (updatedItem.getDescription() != null) item.setDescription(updatedItem.getDescription());
        if (updatedItem.getImageUrl() != null) item.setImageUrl(updatedItem.getImageUrl());
        if (updatedItem.getStatus() != null) item.setStatus(updatedItem.getStatus());
        return itemRepository.save(item);
    }

    public void deleteItem(Long id) {
        itemRepository.deleteById(id);
    }
}
