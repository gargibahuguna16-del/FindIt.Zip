package com.findit.service;

import com.findit.dto.ClaimRequest;
import com.findit.entity.Claim;
import com.findit.entity.Item;
import com.findit.entity.User;
import com.findit.repository.ClaimRepository;
import com.findit.repository.ItemRepository;
import com.findit.repository.UserRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ClaimService {
    private final ClaimRepository claimRepository;
    private final ItemRepository itemRepository;
    private final UserRepository userRepository;

    public ClaimService(ClaimRepository claimRepository, ItemRepository itemRepository, UserRepository userRepository) {
        this.claimRepository = claimRepository;
        this.itemRepository = itemRepository;
        this.userRepository = userRepository;
    }

    public Claim createClaim(ClaimRequest req) {
        Item item = itemRepository.findById(req.getItemId())
                .orElseThrow(() -> new RuntimeException("Item not found"));
        User user = userRepository.findById(req.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Claim claim = new Claim();
        claim.setItem(item);
        claim.setUser(user);
        claim.setProofDetails(req.getProofDetails());
        claim.setStatus("PENDING");

        item.setStatus("CLAIM_REVIEW");
        itemRepository.save(item);

        return claimRepository.save(claim);
    }

    public List<Claim> getAllClaims() {
        return claimRepository.findAllByOrderByCreatedAtDesc();
    }

    public Claim updateClaimStatus(Long id, String status) {
        Claim claim = claimRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Claim not found"));
        claim.setStatus(status);
        Item item = claim.getItem();
        if ("APPROVED".equalsIgnoreCase(status)) {
            item.setStatus("RESOLVED");
        } else if ("REJECTED".equalsIgnoreCase(status)) {
            item.setStatus("ACTIVE");
        }
        itemRepository.save(item);
        return claimRepository.save(claim);
    }
}
